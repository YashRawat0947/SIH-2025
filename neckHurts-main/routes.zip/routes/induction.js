const express = require('express');
const InductionPlan = require('../models/inductionPlan.model');
const Train = require('../models/train.model');
const { authenticateToken, requireSupervisor } = require('../middleware/auth');

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// GET /api/induction/latest - Get latest induction plan
router.get('/latest', async (req, res) => {
  try {
    const plan = await InductionPlan.getLatest();
    
    if (!plan) {
      return res.status(404).json({
        error: 'No induction plan found',
        code: 'NO_PLAN_FOUND',
        suggestion: 'Generate a new plan using POST /api/induction/generate'
      });
    }

    res.json({
      plan,
      summary: plan.summary,
      topTrains: plan.getTopTrains(5),
      criticalAlerts: plan.getCriticalAlerts()
    });

  } catch (error) {
    console.error('Get latest plan error:', error);
    res.status(500).json({
      error: 'Failed to fetch latest plan',
      message: error.message
    });
  }
});

// GET /api/induction/history - Get plan history
router.get('/history', async (req, res) => {
  try {
    const { limit = 10, page = 1 } = req.query;
    
    const plans = await InductionPlan.getHistory(parseInt(limit));
    
    res.json({
      plans,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: plans.length
      }
    });

  } catch (error) {
    console.error('Get plan history error:', error);
    res.status(500).json({
      error: 'Failed to fetch plan history',
      message: error.message
    });
  }
});

// GET /api/induction/explain/:planId - Get detailed explanation for a plan
router.get('/explain/:planId', async (req, res) => {
  try {
    const plan = await InductionPlan.findById(req.params.planId)
      .populate('rankedTrains.train')
      .populate('generatedBy', 'username role');
    
    if (!plan) {
      return res.status(404).json({
        error: 'Plan not found',
        code: 'PLAN_NOT_FOUND'
      });
    }

    // Detailed explanation for each train
    const explanations = plan.rankedTrains.map(entry => ({
      rank: entry.rank,
      train: entry.train,
      reasoning: entry.reasoning,
      confidenceScore: entry.confidenceScore,
      constraints: entry.constraints,
      detailedAnalysis: {
        fitnessStatus: entry.train.fitnessStatus.isValid ? 'Valid' : 'Invalid',
        maintenanceUrgency: entry.train.maintenanceUrgency,
        mileageBalance: entry.train.currentMileage,
        brandingPriority: entry.train.branding.brandingPriority,
        locationAdvantage: entry.train.currentLocation
      }
    }));

    res.json({
      plan: {
        id: plan._id,
        planDate: plan.planDate,
        generatedAt: plan.generatedAt,
        status: plan.status,
        generatedBy: plan.generatedBy
      },
      explanations,
      optimizationMetrics: plan.optimizationMetrics,
      aiModelInfo: plan.aiModelInfo,
      alerts: plan.alerts
    });

  } catch (error) {
    console.error('Get plan explanation error:', error);
    res.status(500).json({
      error: 'Failed to get plan explanation',
      message: error.message
    });
  }
});

// POST /api/induction/generate - Generate new induction plan
router.post('/generate', requireSupervisor, async (req, res) => {
  try {
    const { planDate = new Date(), forceRegenerate = false } = req.body;
    
    // Check if plan already exists for this date
    const existingPlan = await InductionPlan.findOne({ 
      planDate: new Date(planDate),
      status: 'FINALIZED'
    });
    
    if (existingPlan && !forceRegenerate) {
      return res.status(409).json({
        error: 'Plan already exists for this date',
        code: 'PLAN_EXISTS',
        existingPlan: existingPlan._id,
        suggestion: 'Use forceRegenerate: true to override'
      });
    }

    // Get all trains for optimization
    const trains = await Train.find();
    
    if (trains.length === 0) {
      return res.status(400).json({
        error: 'No trains available for optimization',
        code: 'NO_TRAINS_AVAILABLE'
      });
    }

    // Call AI optimization service
    const aiResult = await callAIOptimizer(trains, req.body.constraints);
    
    // Create new induction plan
    const plan = new InductionPlan({
      planDate: new Date(planDate),
      rankedTrains: aiResult.rankedTrains,
      alerts: aiResult.alerts,
      optimizationMetrics: aiResult.metrics,
      generatedBy: req.user._id,
      aiModelInfo: aiResult.modelInfo,
      status: 'FINALIZED'
    });

    await plan.save();
    await plan.populate('rankedTrains.train');

    res.status(201).json({
      message: 'Induction plan generated successfully',
      plan,
      summary: plan.summary,
      processingTime: aiResult.metrics.processingTimeMs
    });

  } catch (error) {
    console.error('Generate plan error:', error);
    res.status(500).json({
      error: 'Failed to generate induction plan',
      message: error.message
    });
  }
});

// POST /api/induction/simulate - Run what-if simulation
router.post('/simulate', requireSupervisor, async (req, res) => {
  try {
    const { trainId, modifications, baseDate = new Date() } = req.body;
    
    if (!trainId || !modifications) {
      return res.status(400).json({
        error: 'trainId and modifications are required',
        code: 'MISSING_SIMULATION_PARAMS'
      });
    }

    // Get current train data
    const trains = await Train.find();
    const targetTrain = trains.find(t => t.trainsetId === trainId);
    
    if (!targetTrain) {
      return res.status(404).json({
        error: 'Train not found for simulation',
        code: 'TRAIN_NOT_FOUND'
      });
    }

    // Apply modifications to train data (in memory only)
    const modifiedTrains = trains.map(train => {
      if (train.trainsetId === trainId) {
        const modified = { ...train.toObject() };
        Object.keys(modifications).forEach(key => {
          modified[key] = modifications[key];
        });
        return modified;
      }
      return train.toObject();
    });

    // Run AI optimization with modified data
    const aiResult = await callAIOptimizer(modifiedTrains, req.body.constraints);
    
    // Create simulation plan (not saved to DB)
    const simulationPlan = {
      planDate: baseDate,
      rankedTrains: aiResult.rankedTrains,
      alerts: aiResult.alerts,
      optimizationMetrics: aiResult.metrics,
      status: 'SIMULATION',
      simulationParams: {
        modifiedTrain: trainId,
        modifications: modifications
      }
    };

    res.json({
      message: 'Simulation completed successfully',
      simulation: simulationPlan,
      changes: {
        trainModified: trainId,
        modifications: modifications,
        impactAnalysis: analyzeSimulationImpact(aiResult.rankedTrains, trainId)
      }
    });

  } catch (error) {
    console.error('Simulation error:', error);
    res.status(500).json({
      error: 'Failed to run simulation',
      message: error.message
    });
  }
});

// Helper function to call AI optimizer
async function callAIOptimizer(trains, constraints = {}) {
  // This will be replaced with actual call to AI optimization script
  // For now, return mock optimization result
  
  const startTime = Date.now();
  
  // Mock AI optimization logic
  const serviceReadyTrains = trains.filter(train => {
    return train.fitnessStatus?.isValid && 
           train.maintenanceStatus === 'OPERATIONAL' && 
           train.isAvailableForService !== false;
  });

  // Simple ranking based on multiple factors
  const rankedTrains = serviceReadyTrains
    .map((train, index) => ({
      train: train._id || train.trainsetId,
      rank: index + 1,
      reasoning: generateMockReasoning(train),
      confidenceScore: Math.floor(Math.random() * 20) + 80, // 80-100
      constraints: {
        fitnessValid: train.fitnessStatus?.isValid || true,
        maintenanceReady: train.maintenanceStatus === 'OPERATIONAL',
        cleaningStatus: train.cleaningStatus || 'CLEAN',
        brandingPriority: train.branding?.brandingPriority || 1,
        mileageBalance: train.currentMileage || 0
      }
    }))
    .sort((a, b) => b.confidenceScore - a.confidenceScore)
    .map((item, index) => ({ ...item, rank: index + 1 }));

  const alerts = generateMockAlerts(trains);
  
  return {
    rankedTrains,
    alerts,
    metrics: {
      totalTrainsEvaluated: trains.length,
      constraintsSatisfied: rankedTrains.length,
      averageConfidence: rankedTrains.reduce((sum, t) => sum + t.confidenceScore, 0) / rankedTrains.length,
      processingTimeMs: Date.now() - startTime
    },
    modelInfo: {
      version: '1.0-mock',
      algorithm: 'Multi-Objective Optimization (Mock)',
      parameters: constraints
    }
  };
}

// Helper function to generate mock reasoning
function generateMockReasoning(train) {
  const reasons = [];
  
  if (train.fitnessStatus?.isValid) {
    reasons.push(`Valid fitness certificate until ${train.fitnessStatus.expiryDate?.toDateString()}`);
  }
  
  if (train.maintenanceStatus === 'OPERATIONAL') {
    reasons.push('Maintenance status: Operational');
  }
  
  if (train.currentMileage) {
    reasons.push(`Balanced mileage: ${train.currentMileage}km`);
  }
  
  if (train.branding?.hasBranding) {
    reasons.push(`Branding priority: ${train.branding.brandingPriority}/5`);
  }
  
  return reasons.join('; ') || 'Selected based on overall optimization criteria';
}

// Helper function to generate mock alerts
function generateMockAlerts(trains) {
  const alerts = [];
  
  trains.forEach(train => {
    if (train.fitnessStatus?.expiryDate) {
      const daysUntilExpiry = Math.floor(
        (train.fitnessStatus.expiryDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );
      
      if (daysUntilExpiry <= 3) {
        alerts.push({
          type: 'CRITICAL',
          message: `${train.trainsetId} fitness certificate expires in ${daysUntilExpiry} days`,
          trainId: train.trainsetId,
          severity: 5
        });
      } else if (daysUntilExpiry <= 7) {
        alerts.push({
          type: 'WARNING',
          message: `${train.trainsetId} fitness certificate expires in ${daysUntilExpiry} days`,
          trainId: train.trainsetId,
          severity: 3
        });
      }
    }
  });
  
  return alerts;
}

// Helper function to analyze simulation impact
function analyzeSimulationImpact(rankedTrains, modifiedTrainId) {
  const modifiedTrainRank = rankedTrains.find(t => 
    t.train === modifiedTrainId || t.train.trainsetId === modifiedTrainId
  )?.rank;
  
  return {
    newRank: modifiedTrainRank,
    rankChange: modifiedTrainRank ? `Moved to rank ${modifiedTrainRank}` : 'Not in top rankings',
    affectedTrains: rankedTrains.length
  };
}

module.exports = router;